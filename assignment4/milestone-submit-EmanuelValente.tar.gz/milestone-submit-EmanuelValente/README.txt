For both tiers you have to have a settings.cfg in root tiers directories.
