Name: Emanuel Carlos de Alcantara Valente

Requirements:

-python2.7
-dropbox 2.2.0 module
-boto module


Note: For both tiers you have to have a settings.cfg in root tiers directories.

